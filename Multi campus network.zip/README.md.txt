# 🌐 Multi-Campus Secure Network Project (Cisco Packet Tracer)

## 📌 Overview
This project simulates a secure multi-campus network using Cisco Packet Tracer. It demonstrates VLAN segmentation, ACL security, dynamic routing (OSPF/RIP), and centralized administration.

---

## 🏗️ Features Implemented

- Multi-campus network topology design
- VLAN segmentation for departments/labs
- ACLs for traffic restriction and security enforcement
- OSPF / RIP dynamic routing configuration
- Central Rector’s Computer for administrative communication
- Campus-specific web servers (HTML simulation)
- Network testing and troubleshooting

---

## 🔐 Security Implementation

### VLANs
- Each campus divided into VLANs
- Isolation between departments (students, labs, admin)

### ACLs
- Restrict unauthorized inter-campus access
- Allow only necessary communication paths

---

## 🌍 Routing

- OSPF / RIP used for inter-campus connectivity
- Ensures dynamic and scalable routing

---

## 🖥️ Central System

A Rector’s Computer is implemented as a centralized control system for communication and monitoring.

---

## 🌐 Web Servers

Each campus includes a simple HTML-based web server with restricted access controlled via ACLs.

---

## 🧪 Testing

Verified:
- VLAN isolation
- Routing functionality
- ACL enforcement
- Server accessibility

---

## 👨‍💻 Author
Chaudhry Abdullah  
BS Robotics & Intelligence Systems